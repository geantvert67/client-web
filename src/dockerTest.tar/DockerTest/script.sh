#!/bin/bash

echo "Je suis un script bash";

ls -a .
